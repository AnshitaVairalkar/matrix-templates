# MATRIX 
## A FILE MANAGEMENT APPLICATION
DJANGO & TAILWIND
```
Setup process
1. Clone the repo
2. Setup the .env file (refer .env.example)
3. Inside jstools, run - npm run build , this will install the required packages for tailwind
4. To start the server use - python manage.py runserver
```
