from django.shortcuts import render, redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required


# Views

def landing(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    else:
        return render(request, 'routes/landing.html')


def user_signup(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.changed_data.get('username')
                messages.success(request, 'Account created for ' + user)
                return redirect('login')

        context = {'form': form}
        return render(request, 'routes/signup.html', context)


def user_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    else:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            print(user)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.info(request, 'Incorrect Username or Password')

        context = {}
        return render(request, 'routes/login.html', context)


def user_logout(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
def dashboard(request):
    members = Member.objects.all()

    return render(request, 'routes/dashboard.html', {'members': members})


@login_required(login_url='login')
def upload_file(request):
    return render(request, 'routes/upload_file.html')


@login_required(login_url='login')
def create(request):
    return render(request, 'routes/create_document.html')


@login_required(login_url='login')
def account(request):
    return render(request, 'routes/account.html')


@login_required(login_url='login')
def notes(request):
    context = {
        "data": [1, 2, 3, 4, 5],
        "category": "Notes"
    }

    return render(request, 'components/category.html', context)


@login_required(login_url='login')
def certificates(request):
    context = {
        "data": [1, 2, 3, 4, 5],
        "category": "Certificates"
    }

    return render(request, 'components/category.html', context)


@login_required(login_url='login')
def documents(request):
    context = {
        "data": [1, 2, 3, 4, 5],
        "category": "Documents"
    }

    return render(request, 'components/category.html', context)


@login_required(login_url='login')
def papers(request):
    context = {
        "data": [1, 2, 3, 4, 5],
        "category": "Question Papers"
    }

    return render(request, 'components/category.html', context)


@login_required(login_url='login')
def material(request):
    context = {
        "data": [1, 2, 3, 4, 5],
        "category": "Study Material"
    }

    return render(request, 'components/category.html', context)
