from . import views
from django.urls import path

urlpatterns = [
    path('', views.landing, name='landing'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.user_signup, name='signup'),
    path('logout/', views.user_logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('upload/', views.upload_file, name='upload'),
    path('create/', views.create, name='create'),
    path('notes/', views.notes, name='notes'),
    path('certificates/', views.certificates, name='certificates'),
    path('documents/', views.documents, name='documents'),
    path('papers/', views.papers, name='papers'),
    path('material/', views.material, name='material'),
    path('account/', views.account, name='account'),
]
